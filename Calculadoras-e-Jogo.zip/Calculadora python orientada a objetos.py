class Calculadora:
    def somar(self, a, b):
        return a + b

    def subtrair(self, a, b):
        return a - b

    def multiplicar(self, a, b):
        return a * b

    def dividir(self, a, b):
        if b == 0:
            return "Erro: não é possível dividir por zero."
        return a / b


def mostrar_menu():
    print("\n=== CALCULADORA ORIENTADA A OBJETOS ===")
    print("1 - Somar")
    print("2 - Subtrair")
    print("3 - Multiplicar")
    print("4 - Dividir")
    print("0 - Sair")


calculadora = Calculadora()

while True:
    mostrar_menu()

    opcao = input("Escolha uma opção: ")

    if opcao == "0":
        print("Calculadora encerrada.")
        break

    if opcao in ["1", "2", "3", "4"]:
        try:
            num1 = float(input("Digite o primeiro número: "))
            num2 = float(input("Digite o segundo número: "))

            if opcao == "1":
                resultado = calculadora.somar(num1, num2)
            elif opcao == "2":
                resultado = calculadora.subtrair(num1, num2)
            elif opcao == "3":
                resultado = calculadora.multiplicar(num1, num2)
            elif opcao == "4":
                resultado = calculadora.dividir(num1, num2)

            print("Resultado:", resultado)

        except ValueError:
            print("Erro: digite apenas números válidos.")
    else:
        print("Opção inválida. Tente novamente.")