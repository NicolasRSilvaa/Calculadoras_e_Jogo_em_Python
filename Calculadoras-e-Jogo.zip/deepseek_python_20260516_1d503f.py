import pygame
import random
import math
import sys
import time
import os
from threading import Thread

# ==============================================================================
# 1. CONFIGURAÇÕES INICIAIS
# ==============================================================================
pygame.init()
pygame.mixer.init(frequency=44100, size=-16, channels=2, buffer=512)

# Configurações de tela
LARGURA = 1024
ALTURA = 768
TELA = pygame.display.set_mode((LARGURA, ALTURA))
pygame.display.set_caption("🎸 GUITAR HERO 3D - Sweet Child O' Mine 🎸")
clock = pygame.time.Clock()

# Cores
PRETO = (0, 0, 0)
BRANCO = (255, 255, 255)
VERDE = (0, 255, 0)
VERMELHO = (255, 0, 0)
AMARELO = (255, 255, 0)
AZUL = (0, 0, 255)
CINZA = (100, 100, 100)
CINZA_ESCURO = (40, 40, 40)
DOURADO = (255, 215, 0)
LARANJA = (255, 100, 0)
ROXO = (255, 0, 255)
CIANO = (0, 255, 255)

# Configurações do jogo
NOTAS_CORES = [VERDE, VERMELHO, AMARELO, AZUL]
TECLAS = [pygame.K_a, pygame.K_s, pygame.K_d, pygame.K_f]
NOMES_TECLAS = ['A', 'S', 'D', 'F']
X_POSICOES = [-0.6, -0.2, 0.2, 0.6]

def x_para_tela(x):
    return LARGURA // 2 + x * (LARGURA // 3.5)

velocidade_nota = 350
pontuacao = 0
combo = 0
notas_acertadas = 0
notas_totais = 0
multiplicador = 1
rodando = True
jogo_ativo = True
tempo_inicio_jogo = 0
musica_comecou = False
primeira_nota_gerada = False

# ==============================================================================
# 2. SISTEMA DE ÁUDIO - Sweet Child O' Mine
# ==============================================================================

# Lista de possíveis nomes de arquivo
NOMES_ARQUIVOS = [
    "Guns_N_Roses_Sweet_Child_O_Mine.mp3",
    "sweet_child_o_mine.mp3",
    "sweet_child.mp3",
    "guns_and_roses_sweet_child.mp3"
]

musica_disponivel = False
arquivo_carregado = None
duracao_musica = 0

# Tentar carregar música
for nome_arquivo in NOMES_ARQUIVOS:
    if os.path.exists(nome_arquivo):
        try:
            pygame.mixer.music.load(nome_arquivo)
            musica_disponivel = True
            arquivo_carregado = nome_arquivo
            try:
                som_temp = pygame.mixer.Sound(nome_arquivo)
                duracao_musica = som_temp.get_length()
                print(f"✅ Música carregada: {nome_arquivo}")
                print(f"🎵 Duração: {duracao_musica:.1f} segundos")
            except:
                duracao_musica = 330  # 5 minutos e 30 segundos
            break
        except Exception as e:
            print(f"❌ Erro ao carregar {nome_arquivo}: {e}")

if not musica_disponivel:
    print("=" * 60)
    print("❌ Nenhum arquivo de música encontrado!")
    print("💡 Coloque um arquivo MP3 na pasta do jogo")
    print("💡 Usando versão sintetizada...")
    print("=" * 60)
    duracao_musica = 330.0  # 5 minutos e 30 segundos

# ==============================================================================
# NOTAS COMPLETAS DA MÚSICA - Sweet Child O' Mine (330 segundos)
# ==============================================================================

# Função para gerar sequência completa de notas
def gerar_notas_completas():
    notas = []
    
    # Intro - Riff principal (0-30 segundos)
    intro_riff = [329.63, 329.63, 329.63, 293.66, 329.63, 329.63, 329.63, 293.66,
                  329.63, 329.63, 329.63, 293.66, 329.63, 392.00, 440.00, 440.00]
    
    # Primeiro verso (30-60 segundos)
    primeiro_verso = [392.00, 349.23, 329.63, 329.63, 349.23, 392.00, 440.00, 440.00,
                      392.00, 349.23, 329.63, 329.63, 349.23, 392.00, 440.00, 440.00]
    
    # Refrão (60-90 segundos)
    refrao = [440.00, 440.00, 392.00, 440.00, 440.00, 440.00, 392.00, 349.23,
              329.63, 329.63, 349.23, 392.00, 440.00, 440.00, 392.00, 349.23]
    
    # Solo parte 1 (90-120 segundos)
    solo1 = [523.25, 493.88, 440.00, 392.00, 440.00, 493.88, 523.25, 493.88,
             440.00, 392.00, 349.23, 329.63, 392.00, 440.00, 493.88, 523.25]
    
    # Solo parte 2 (120-150 segundos)
    solo2 = [587.33, 523.25, 493.88, 440.00, 493.88, 523.25, 587.33, 523.25,
             493.88, 440.00, 392.00, 349.23, 440.00, 493.88, 523.25, 587.33]
    
    # Ponte (150-180 segundos)
    ponte = [440.00, 392.00, 440.00, 392.00, 349.23, 329.63, 349.23, 392.00,
             440.00, 392.00, 440.00, 392.00, 349.23, 329.63, 392.00, 440.00]
    
    # Solo parte 3 (180-210 segundos)
    solo3 = [659.25, 587.33, 523.25, 493.88, 523.25, 587.33, 659.25, 587.33,
             523.25, 493.88, 440.00, 392.00, 493.88, 523.25, 587.33, 659.25]
    
    # Segundo verso (210-240 segundos)
    segundo_verso = [329.63, 329.63, 349.23, 392.00, 440.00, 440.00, 392.00, 349.23,
                     329.63, 329.63, 349.23, 392.00, 440.00, 440.00, 392.00, 349.23]
    
    # Refrão final (240-270 segundos)
    refrao_final = [440.00, 440.00, 392.00, 440.00, 440.00, 440.00, 392.00, 349.23,
                    329.63, 329.63, 349.23, 392.00, 440.00, 440.00, 392.00, 349.23,
                    440.00, 440.00, 392.00, 440.00, 440.00, 440.00, 392.00, 349.23]
    
    # Final (270-300 segundos)
    final = [329.63, 329.63, 349.23, 392.00, 440.00, 440.00, 392.00, 349.23,
             329.63, 329.63, 349.23, 392.00, 440.00, 440.00, 392.00, 349.23, 329.63]
    
    # Riff de encerramento (300-330 segundos)
    encerramento = [329.63, 293.66, 329.63, 293.66, 329.63, 392.00, 440.00, 392.00,
                    329.63, 293.66, 329.63, 293.66, 329.63, 392.00, 440.00, 392.00,
                    329.63]
    
    # Combinar todas as seções
    todas_notas = (intro_riff * 2) + primeiro_verso + refrao + solo1 + solo2 + ponte + \
                  solo3 + segundo_verso + refrao_final + final + encerramento
    
    return todas_notas

# Gerar notas completas
MELODIA_NOTAS = gerar_notas_completas()

# Gerar tempos para cada nota (baseado em 120 BPM = 0.5 segundos por nota)
TEMPOS_NOTAS = []
tempo_atual = 0.5
for i in range(len(MELODIA_NOTAS)):
    # Variação rítmica para simular a música real
    if i % 8 == 0 and i > 0:
        tempo_atual += 0.6  # Pausa entre frases
    elif i % 4 == 0:
        tempo_atual += 0.5  # Nota normal
    elif i % 2 == 0:
        tempo_atual += 0.4  # Nota rápida
    else:
        tempo_atual += 0.45  # Nota média
    
    TEMPOS_NOTAS.append(tempo_atual)

# Ajustar para não ultrapassar a duração da música
if TEMPOS_NOTAS and TEMPOS_NOTAS[-1] > duracao_musica:
    fator_ajuste = duracao_musica / TEMPOS_NOTAS[-1]
    TEMPOS_NOTAS = [t * fator_ajuste for t in TEMPOS_NOTAS]

print(f"🎵 Total de notas geradas: {len(MELODIA_NOTAS)}")
print(f"🎵 Duração total das notas: {TEMPOS_NOTAS[-1]:.1f} segundos")

# ==============================================================================
# 3. CLASSE DAS NOTAS
# ==============================================================================
class Nota:
    def __init__(self, x, cor, indice, tecla, nota_index, y=100):
        self.x = x
        self.y = y
        self.cor = cor
        self.indice = indice
        self.tecla = tecla
        self.nota_index = nota_index
        self.ativo = True
        self.animacao_brilho = 0
        self.angulo = 0
        self.criado_em = time.time()
        
    def update(self, dt):
        self.y += velocidade_nota * dt
        self.angulo += 5
        
    def desenhar(self, tela):
        tela_x = x_para_tela(self.x)
        
        brilho = int(50 + 30 * math.sin(self.animacao_brilho))
        self.animacao_brilho += 0.1
        cor_brilho = tuple(min(255, c + brilho) for c in self.cor)
        
        altura_nota = 30
        largura_nota = 45
        
        # Sombra
        pygame.draw.ellipse(tela, CINZA_ESCURO, (tela_x - largura_nota//2 + 3, 
                                                   self.y - altura_nota//2 + 3, 
                                                   largura_nota, altura_nota))
        
        # Corpo principal
        pygame.draw.ellipse(tela, cor_brilho, (tela_x - largura_nota//2, 
                                                self.y - altura_nota//2, 
                                                largura_nota, altura_nota))
        
        # Brilho
        pygame.draw.ellipse(tela, BRANCO, (tela_x - largura_nota//4, 
                                            self.y - altura_nota//4, 
                                            largura_nota//2, altura_nota//2), 2)
        
        # Letra da tecla
        fonte = pygame.font.Font(None, 24)
        texto = fonte.render(NOMES_TECLAS[self.indice], True, BRANCO)
        tela.blit(texto, (tela_x - 10, self.y - 10))

# ==============================================================================
# 4. SISTEMA DE PARTÍCULAS
# ==============================================================================
class Particula:
    def __init__(self, x, y, cor):
        self.x = x
        self.y = y
        self.vx = random.uniform(-4, 4)
        self.vy = random.uniform(-10, -2)
        self.cor = cor
        self.vida = 1.0
        self.tamanho = random.randint(2, 7)
        
    def update(self, dt):
        self.x += self.vx * dt * 60
        self.y += self.vy * dt * 60
        self.vy += 8 * dt * 60
        self.vida -= dt * 4
        return self.vida > 0
        
    def desenhar(self, tela):
        cor = tuple(min(255, c * self.vida) for c in self.cor)
        pygame.draw.circle(tela, cor, (int(self.x), int(self.y)), self.tamanho)

particulas = []

def criar_explosao(x, y, cor):
    for _ in range(25):
        particulas.append(Particula(x, y, cor))

# ==============================================================================
# 5. SISTEMA DE GERAÇÃO DE NOTAS
# ==============================================================================
notas = []
indice_musica = 0
ultimo_tempo_geracao = 0

def instanciar_nota():
    global indice_musica, notas_totais
    
    if indice_musica < len(MELODIA_NOTAS):
        freq = MELODIA_NOTAS[indice_musica]
        
        # Mapear frequência para posição baseado na nota musical real
        if freq <= 300:
            indice = 0  # A - Verde
        elif freq <= 350:
            indice = 1  # S - Vermelho
        elif freq <= 450:
            indice = 2  # D - Amarelo
        elif freq <= 550:
            indice = 3  # F - Azul
        else:
            indice = random.choice([2, 3])  # Notas muito agudas
        
        nota = Nota(X_POSICOES[indice], NOTAS_CORES[indice], indice, TECLAS[indice], indice_musica, y=60)
        notas.append(nota)
        notas_totais += 1
        
        indice_musica += 1
        return True
    return False

# ==============================================================================
# 6. FUNÇÕES DE DESENHO
# ==============================================================================
def desenhar_pista():
    # Fundo gradiente
    for i in range(ALTURA):
        gradiente = int(20 + (i / ALTURA) * 100)
        pygame.draw.line(TELA, (gradiente//2, gradiente//2, gradiente + 50), (0, i), (LARGURA, i))
    
    y_alvo = ALTURA - 150
    largura_pista = 520
    
    # Pista
    pygame.draw.rect(TELA, CINZA_ESCURO, (LARGURA//2 - largura_pista//2, 0, largura_pista, ALTURA))
    pygame.draw.rect(TELA, CINZA, (LARGURA//2 - largura_pista//2, 0, largura_pista, ALTURA), 3)
    
    # Divisórias
    for i in range(1, 4):
        x = LARGURA//2 - largura_pista//2 + i * (largura_pista // 4)
        pygame.draw.line(TELA, CINZA, (x, 0), (x, ALTURA), 3)
    
    # Linha de impacto
    pygame.draw.rect(TELA, VERMELHO, (LARGURA//2 - largura_pista//2, y_alvo - 20, largura_pista, 40))
    pygame.draw.rect(TELA, DOURADO, (LARGURA//2 - largura_pista//2, y_alvo - 20, largura_pista, 40), 3)
    
    # Brilho
    brilho = int(50 + 30 * math.sin(pygame.time.get_ticks() * 0.005))
    pygame.draw.rect(TELA, (255, brilho, brilho), (LARGURA//2 - largura_pista//2, y_alvo - 20, largura_pista, 40), 2)
    
    return y_alvo

def desenhar_botoes(y_alvo):
    for i, tecla in enumerate(NOMES_TECLAS):
        tela_x = x_para_tela(X_POSICOES[i])
        cor_botao = NOTAS_CORES[i]
        
        pygame.draw.rect(TELA, CINZA_ESCURO, (tela_x - 35, y_alvo - 25, 70, 55))
        pygame.draw.rect(TELA, cor_botao, (tela_x - 35, y_alvo - 30, 70, 55))
        pygame.draw.rect(TELA, BRANCO, (tela_x - 35, y_alvo - 30, 70, 55), 3)
        
        fonte = pygame.font.Font(None, 36)
        texto = fonte.render(tecla, True, BRANCO)
        TELA.blit(texto, (tela_x - 12, y_alvo - 18))
        
        if tecla_pressionada[i]:
            pygame.draw.rect(TELA, BRANCO, (tela_x - 35, y_alvo - 30, 70, 55), 5)
            glow = pygame.Surface((80, 65))
            glow.set_alpha(100)
            glow.fill(cor_botao)
            TELA.blit(glow, (tela_x - 40, y_alvo - 35))

def desenhar_interface():
    fonte = pygame.font.Font(None, 52)
    
    texto_score = fonte.render(f"⭐ SCORE: {pontuacao}", True, DOURADO)
    TELA.blit(texto_score, (20, 20))
    
    if combo > 0:
        cor_combo = LARANJA if combo < 10 else VERMELHO if combo < 20 else DOURADO
        texto_combo = fonte.render(f"🔥 COMBO: {combo}", True, cor_combo)
    else:
        texto_combo = fonte.render(f"COMBO: {combo}", True, CINZA)
    TELA.blit(texto_combo, (20, 80))
    
    texto_multi = fonte.render(f"✧ MULTI: {multiplicador}x", True, CIANO)
    TELA.blit(texto_multi, (20, 140))
    
    if notas_totais > 0:
        accuracy = (notas_acertadas / notas_totais) * 100
        cor_acc = VERDE if accuracy > 80 else AMARELO if accuracy > 60 else VERMELHO
        texto_acc = fonte.render(f"🎯 ACC: {accuracy:.1f}%", True, cor_acc)
        TELA.blit(texto_acc, (LARGURA - 250, 20))
    
    # Barra de progresso da música
    if musica_disponivel:
        progresso = pygame.mixer.music.get_pos() / 1000.0
        if progresso > 0 and duracao_musica > 0:
            largura_barra = 400
            porcentagem = min(1.0, progresso / duracao_musica)
            pygame.draw.rect(TELA, CINZA, (LARGURA//2 - largura_barra//2, ALTURA - 60, largura_barra, 10))
            pygame.draw.rect(TELA, DOURADO, (LARGURA//2 - largura_barra//2, ALTURA - 60, largura_barra * porcentagem, 10))
            
            tempo_restante = max(0, duracao_musica - progresso)
            tempo_fonte = pygame.font.Font(None, 20)
            texto_tempo = tempo_fonte.render(f"{int(progresso//60)}:{int(progresso%60):02d} / {int(duracao_musica//60)}:{int(duracao_musica%60):02d}", True, CINZA)
            TELA.blit(texto_tempo, (LARGURA//2 - 50, ALTURA - 75))
    
    # Contador de notas
    nota_fonte = pygame.font.Font(None, 24)
    texto_notas = nota_fonte.render(f"Notas: {notas_acertadas}/{notas_totais}", True, CINZA)
    TELA.blit(texto_notas, (20, ALTURA - 30))
    
    # Status da música
    info_fonte = pygame.font.Font(None, 24)
    if musica_disponivel:
        status_texto = info_fonte.render(f"🎵 {arquivo_carregado} (100% vol)", True, VERDE)
    else:
        status_texto = info_fonte.render(f"🎵 Modo Sintetizado", True, AMARELO)
    TELA.blit(status_texto, (20, ALTURA - 60))
    
    # Dica das teclas
    dica_fonte = pygame.font.Font(None, 20)
    dica_texto = dica_fonte.render("A - S - D - F | Acerte as notas no ritmo!", True, CINZA)
    TELA.blit(dica_texto, (LARGURA - 300, ALTURA - 30))

def desenhar_fim_de_jogo():
    overlay = pygame.Surface((LARGURA, ALTURA))
    overlay.set_alpha(200)
    overlay.fill(PRETO)
    TELA.blit(overlay, (0, 0))
    
    fonte_titulo = pygame.font.Font(None, 72)
    fonte_texto = pygame.font.Font(None, 48)
    
    titulo = fonte_titulo.render("🏆 GAME COMPLETE! 🏆", True, DOURADO)
    texto_final = fonte_texto.render(f"Final Score: {pontuacao}", True, BRANCO)
    
    if notas_totais > 0:
        accuracy = (notas_acertadas / notas_totais) * 100
        texto_acc = fonte_texto.render(f"Accuracy: {accuracy:.1f}%", True, CIANO)
        TELA.blit(texto_acc, (LARGURA//2 - texto_acc.get_width()//2, ALTURA//2 + 20))
    
    if notas_totais > 0:
        acc_ratio = notas_acertadas / notas_totais
        if acc_ratio > 0.9:
            ranking = "🌟 ROCK STAR! 🌟"
        elif acc_ratio > 0.7:
            ranking = "🎸 GUITAR HERO! 🎸"
        elif acc_ratio > 0.5:
            ranking = "👍 GOOD JOB! 👍"
        else:
            ranking = "💪 KEEP PRACTICING! 💪"
    else:
        ranking = "💪 KEEP PRACTICING! 💪"
    
    texto_rank = fonte_texto.render(ranking, True, DOURADO)
    texto_restart = fonte_texto.render("Press R to restart or ESC to quit", True, CINZA)
    
    TELA.blit(titulo, (LARGURA//2 - titulo.get_width()//2, ALTURA//2 - 120))
    TELA.blit(texto_final, (LARGURA//2 - texto_final.get_width()//2, ALTURA//2 - 40))
    TELA.blit(texto_rank, (LARGURA//2 - texto_rank.get_width()//2, ALTURA//2 + 70))
    TELA.blit(texto_restart, (LARGURA//2 - texto_restart.get_width()//2, ALTURA//2 + 140))

# ==============================================================================
# 7. FUNÇÃO PARA TOCAR MÚSICA COMPLETA
# ==============================================================================
def tocar_musica_completa():
    """Toca o arquivo de música completo"""
    pygame.mixer.music.play()
    pygame.mixer.music.set_volume(1.0)  # Volume 100%

# ==============================================================================
# 8. LOOP PRINCIPAL
# ==============================================================================
tecla_pressionada = [False, False, False, False]

# Iniciar música
if musica_disponivel:
    tocar_musica_completa()
    print("🎵 Música em 100% de volume")
    print(f"🎵 Duração total: {duracao_musica:.1f} segundos")
else:
    # Versão sintetizada simplificada
    def tocar_musica_sintetizada_simples():
        time.sleep(0.5)
        # Apenas toca um som de fundo simples
        pass
    
    thread_musica = Thread(target=tocar_musica_sintetizada_simples, daemon=True)
    thread_musica.start()
    print("🎵 Modo sintetizado ativado")

# Pequena pausa antes de começar as notas
time.sleep(0.5)
tempo_inicio_jogo = time.time()
ultimo_tempo_geracao = 0

while rodando:
    dt = clock.tick(60) / 1000.0
    
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            rodando = False
        
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                rodando = False
            elif event.key == pygame.K_r and not jogo_ativo:
                # Reiniciar jogo
                pontuacao = 0
                combo = 0
                multiplicador = 1
                notas_acertadas = 0
                notas_totais = 0
                indice_musica = 0
                notas.clear()
                particulas.clear()
                jogo_ativo = True
                
                if musica_disponivel:
                    pygame.mixer.music.stop()
                    pygame.mixer.music.play()
                    pygame.mixer.music.set_volume(1.0)
                
                tempo_inicio_jogo = time.time()
                ultimo_tempo_geracao = 0
                time.sleep(0.5)
            
            # Verificar teclas do jogo
            if jogo_ativo:
                for i, tecla in enumerate(TECLAS):
                    if event.key == tecla:
                        tecla_pressionada[i] = True
                        
                        y_alvo = ALTURA - 150
                        for nota in notas[:]:
                            if nota.tecla == tecla and abs(nota.y - y_alvo) < 50:
                                timing = max(0, 1 - abs(nota.y - y_alvo) / 50)
                                pontos_nota = int(100 * timing * multiplicador)
                                
                                if timing > 0.95:
                                    pontos_nota += 50
                                    criar_explosao(x_para_tela(nota.x), nota.y, BRANCO)
                                else:
                                    criar_explosao(x_para_tela(nota.x), nota.y, nota.cor)
                                
                                pontuacao += pontos_nota
                                combo += 1
                                notas_acertadas += 1
                                
                                if combo >= 30:
                                    multiplicador = 4
                                elif combo >= 20:
                                    multiplicador = 3
                                elif combo >= 10:
                                    multiplicador = 2
                                else:
                                    multiplicador = 1
                                
                                notas.remove(nota)
                                break
        
        elif event.type == pygame.KEYUP:
            for i, tecla in enumerate(TECLAS):
                if event.key == tecla:
                    tecla_pressionada[i] = False
    
    if jogo_ativo:
        y_alvo = ALTURA - 150
        for nota in notas[:]:
            nota.update(dt)
            
            if nota.y > y_alvo + 55:
                if nota in notas:
                    combo = 0
                    multiplicador = 1
                    notas.remove(nota)
                    criar_explosao(x_para_tela(nota.x), nota.y, VERMELHO)
        
        # Gerar novas notas baseado no tempo da música
        if musica_disponivel:
            if indice_musica < len(TEMPOS_NOTAS):
                tempo_musica = pygame.mixer.music.get_pos() / 1000.0
                if tempo_musica >= 0 and tempo_musica >= TEMPOS_NOTAS[indice_musica]:
                    instanciar_nota()
        else:
            tempo_atual = time.time() - tempo_inicio_jogo
            if indice_musica < len(TEMPOS_NOTAS):
                if tempo_atual >= TEMPOS_NOTAS[indice_musica]:
                    instanciar_nota()
        
        # Verificar fim do jogo
        if musica_disponivel:
            tempo_musica = pygame.mixer.music.get_pos() / 1000.0
            if tempo_musica >= duracao_musica - 1 or (indice_musica >= len(MELODIA_NOTAS) and len(notas) == 0):
                jogo_ativo = False
        else:
            if indice_musica >= len(MELODIA_NOTAS) and len(notas) == 0:
                jogo_ativo = False
    
    # Desenhar
    y_alvo = desenhar_pista()
    desenhar_botoes(y_alvo)
    
    for nota in notas:
        nota.desenhar(TELA)
    
    for particula in particulas[:]:
        if not particula.update(1/60):
            particulas.remove(particula)
        else:
            particula.desenhar(TELA)
    
    desenhar_interface()
    
    if not jogo_ativo:
        desenhar_fim_de_jogo()
    
    pygame.display.flip()

pygame.quit()
sys.exit()